/* Name:Alica Sailer
     Matrikel:256030
     Datum:21.02.2018
     Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe. Er wurde nicht kopiert und nicht diktiert. */
var Final;
(function (Final) {
    var CanvasObjects = (function () {
        function CanvasObjects(_x, _y) {
            this.x = _x;
            this.y = _y;
        }
        return CanvasObjects;
    }());
    Final.CanvasObjects = CanvasObjects;
})(Final || (Final = {}));
//# sourceMappingURL=CanvasObjects.js.map